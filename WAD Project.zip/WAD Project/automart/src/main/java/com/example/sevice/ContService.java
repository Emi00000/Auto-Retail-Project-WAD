package com.example.sevice;

import com.example.domain.Cont;
import com.example.repository.ContRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContService {

    @Autowired
    private ContRepository contRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<Cont> getAllConts() {
        return contRepository.findAll();
    }

    public Cont saveCont(Cont cont) {
        cont.setParola(passwordEncoder.encode(cont.getParola()));
        return contRepository.save(cont);
    }

    public Cont getContById(Long id) {
        return contRepository.findById(id).orElse(null);
    }
}
