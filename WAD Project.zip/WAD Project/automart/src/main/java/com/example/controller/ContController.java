package com.example.controller;

import com.example.domain.Cont;
import com.example.service.ContService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ContController {
    @Autowired
    private ContService contService;

    @GetMapping("/conts")
    public String getConts(Model model) {
        model.addAttribute("conts", contService.getAllConts());
        return "cont-list";
    }

    @PostMapping("/conts")
    public String saveCont(Cont cont) {
        contService.saveCont(cont);
        return "redirect:/conts";
    }
}
