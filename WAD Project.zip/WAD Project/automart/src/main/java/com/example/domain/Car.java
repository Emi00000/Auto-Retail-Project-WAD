package com.example.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.blob;

@Entity
public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    //private blob poza;
    private String brand;
    private String model;
    private int anFabricatie;
    private String motorizare;
    private int kmRulaj;
    private String tipCombustibil;
    private int putere;
    private String trasmisie;
    private int nrmaPoluare;
    private float consumMixt;
    private String caroserie;
    private int nrPortiere;
    private String culoare;
    private String primaInmatriculare;
    private String stare;
    private String oferitDe;
    private String VIN;
    private String descriere;
    private Long contId;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //public String getPoza() {
      //  return poza;
    //}

    //public void setPoza(String poza) {
      //  this.poza = poza;
   // }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getAnFabricatie() {
        return anFabricatie;
    }

    public void setAnFabricatie(int anFabricatie) {
        this.anFabricatie = anFabricatie;
    }

    public String getMotorizare() {
        return motorizare;
    }

    public void setMotorizare(String motorizare) {
        this.motorizare = motorizare;
    }

    public int getKmRulaj() {
        return kmRulaj;
    }

    public void setKmRulaj(int kmRulaj) {
        this.kmRulaj = kmRulaj;
    }

    public String getTipCombustibil() {
        return tipCombustibil;
    }

    public void setTipCombustibil(String tipCombustibil) {
        this.tipCombustibil = tipCombustibil;
    }

    public int getPutere() {
        return putere;
    }

    public void setPutere(int putere) {
        this.putere = putere;
    }

    public String getTrasmisie() {
        return trasmisie;
    }

    public void setTrasmisie(String trasmisie) {
        this.trasmisie = trasmisie;
    }

    public int getNrmaPoluare() {
        return nrmaPoluare;
    }

    public void setNrmaPoluare(int nrmaPoluare) {
        this.nrmaPoluare = nrmaPoluare;
    }

    public float getConsumMixt() {
        return consumMixt;
    }

    public void setConsumMixt(float consumMixt) {
        this.consumMixt = consumMixt;
    }

    public String getCaroserie() {
        return caroserie;
    }

    public void setCaroserie(String caroserie) {
        this.caroserie = caroserie;
    }

    public int getNrPortiere() {
        return nrPortiere;
    }

    public void setNrPortiere(int nrPortiere) {
        this.nrPortiere = nrPortiere;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public String getPrimaInmatriculare() {
        return primaInmatriculare;
    }

    public void setPrimaInmatriculare(String primaInmatriculare) {
        this.primaInmatriculare = primaInmatriculare;
    }

    public String getStare() {
        return stare;
    }

    public void setStare(String stare) {
        this.stare = stare;
    }

    public String getOferitDe() {
        return oferitDe;
    }

    public void setOferitDe(String oferitDe) {
        this.oferitDe = oferitDe;
    }

    public String getVIN() {
        return VIN;
    }

    public void setVIN(String VIN) {
        this.VIN = VIN;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Long getContId() {
        return contId;
    }

    public void setContId(Long contId) {
        this.contId = contId;
    }
}

