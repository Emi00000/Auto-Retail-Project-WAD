package com.example.repository;

import com.example.domain.Cont;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ContRepository extends JpaRepository<Cont, Long> {
    Optional<Cont> findByUsername(String username);
}
